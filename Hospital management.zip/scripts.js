document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    const userType = validateCredentials(username, password);
    
    if (userType) {
        // Redirect based on user type
        if (userType === 'doctor') {
            window.location.href = 'doctor-dashboard.html';
        } else if (userType === 'patient') {
            window.location.href = 'patient-dashboard.html';
        } else if (userType === 'hospital') {
            window.location.href = 'hospital-dashboard.html';
        }
    } else {
        document.getElementById('error-message').innerText = 'Invalid username or password';
    }
});

function validateCredentials(username, password) {
    // Dummy validation logic with predefined users
    const users = {
        doctor: { username: 'doctor', password: 'doc123' },
        patient: { username: 'patient', password: 'pat123' },
        hospital: { username: 'hospital', password: 'hos123' }
    };

    for (const userType in users) {
        if (username === users[userType].username && password === users[userType].password) {
            return userType;
        }
    }
    return null;
}
